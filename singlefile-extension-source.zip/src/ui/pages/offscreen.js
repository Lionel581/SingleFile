/* global chrome */

// Offscreen document for MV3 compatibility
// Handles background tasks that require DOM/window context
